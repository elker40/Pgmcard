/*
 * PageMenu.c
 *
 *  Created on: 2016-8-17
 *      Author: Administrator
 */

#include "PageMenu.h"

SI_SEGMENT_VARIABLE( PageOptionDirectionDef[4],CSTR,SI_SEG_XDATA) ;
SI_SEGMENT_VARIABLE( PageOptionModelTypeDef[3],CSTR,SI_SEG_XDATA) ;
SI_SEGMENT_VARIABLE( PageOptionFlyModeDef[4],CSTR,SI_SEG_XDATA) ;


//Switch select
SI_SEGMENT_VARIABLE(SwitchA[],const char,SI_SEG_CODE) = {0xbf,0xaa,0xb9,0xd8,0x41,0x00,0} ;
SI_SEGMENT_VARIABLE(SwitchB[],const char,SI_SEG_CODE) = {0xbf,0xaa,0xb9,0xd8,0x42,0x00,0} ;
SI_SEGMENT_VARIABLE(SwitchD[],const char,SI_SEG_CODE) = {0xbf,0xaa,0xb9,0xd8,0x44,0x00,0} ;
SI_SEGMENT_VARIABLE(SwitchE[],const char,SI_SEG_CODE) = {0xbf,0xaa,0xb9,0xd8,0x45,0x00,0} ;
SI_SEGMENT_VARIABLE( PageOptionSwitchEn[4],CSTR,SI_SEG_CODE) = {"SA","SB","SD","SE"} ;
SI_SEGMENT_VARIABLE( PageOptionSwitchCn[4],CSTR,SI_SEG_CODE) = {SwitchA,SwitchB,SwitchD,SwitchE} ;
SI_SEGMENT_VARIABLE( PageOptionSwitchDef[4],CSTR,SI_SEG_XDATA) ;


//mounting direction
SI_SEGMENT_VARIABLE( FaceUp[5],const char,SI_SEG_CODE) = {0xd5,0xfd,0xcf,0xf2,0} ;
SI_SEGMENT_VARIABLE( FaceDw[5],const char,SI_SEG_CODE) = {0xb7,0xb4,0xcf,0xf2,0} ;
SI_SEGMENT_VARIABLE( FaceLf[7],const char,SI_SEG_CODE) = {0xd7,0xf3,0xb2,0xe0,0xcf,0xf2,0};
SI_SEGMENT_VARIABLE( FaceLRi[7],const char,SI_SEG_CODE) = {0xd3,0xd2,0xb2,0xe0,0xcf,0xf2,0};
SI_SEGMENT_VARIABLE(PageOptionDirectionCn[4],CSTR,SI_SEG_CODE) = {FaceUp,FaceDw,FaceLf,FaceLRi};
SI_SEGMENT_VARIABLE( PageOptionDirectionEn[],CSTR,SI_SEG_CODE) = {"FU","FD","FR","FL"};


SI_SEGMENT_VARIABLE( NormalWings[7],const char,SI_SEG_CODE) = {0xb3,0xa3,0xb9,0xe6,0xd2,0xed,0} ;
SI_SEGMENT_VARIABLE(TriangleWings[7],const char ,SI_SEG_CODE) = {0xc8,0xfd,0xbd,0xc7,0xd2,0xed,0};
SI_SEGMENT_VARIABLE(VWings[9],const char ,SI_SEG_CODE) = {0x01,0x01,0xd0,0xcd,0xce,0xb2,0xd2,0xed,0};
SI_SEGMENT_VARIABLE( PageOptionModelTypeCn[],CSTR,SI_SEG_CODE) = {NormalWings,TriangleWings,VWings} ;
SI_SEGMENT_VARIABLE( PageOptionModelTypeEn[],CSTR,SI_SEG_CODE)= {"Normal","Delta Wing","V-tail"};

SI_SEGMENT_VARIABLE( GyroOff[9],const char,SI_SEG_CODE) = {0xb9,0xd8,0xb1,0xd5,0xc4,0xa3,0xca,0xbd,0};
SI_SEGMENT_VARIABLE( Normal[9],const char,SI_SEG_CODE) = {0xc6,0xd5,0xcd,0xa8,0xc4,0xa3,0xca,0xbd,0};
SI_SEGMENT_VARIABLE( Safe[9],const char,SI_SEG_CODE) = {0xb0,0xb2,0xc8,0xab,0xc4,0xa3,0xca,0xbd,0};
SI_SEGMENT_VARIABLE( Aerobitic[9],const char,SI_SEG_CODE) = {0xcb,0xf8,0xb6,0xa8,0xc4,0xa3,0xca,0xbd,0};
SI_SEGMENT_VARIABLE( PageOptionFlyModeCn[4],CSTR,SI_SEG_CODE) = {GyroOff,Normal,Safe,Aerobitic};
SI_SEGMENT_VARIABLE( PageOptionFlyModeEn[],CSTR,SI_SEG_CODE)= {"Gyro Off","Normal","safe","Aerobatic"};

SI_SEGMENT_VARIABLE( PageOptionGainDirCn[],CSTR,SI_SEG_CODE)={FaceUp,FaceDw};
SI_SEGMENT_VARIABLE( PageOptionGainDirEn[],CSTR,SI_SEG_CODE)= {"Normal","Reverse"};

SI_SEGMENT_VARIABLE( PageOptionGainDirDef[2],CSTR,SI_SEG_XDATA) ;
SI_SEGMENT_VARIABLE( AirParameter[14],int16_t,SI_SEG_IDATA) ;

//chinese display
SI_SEGMENT_VARIABLE(AirZWCn[],const char ,SI_SEG_CODE) = {0xb9,0xcc,0xb6,0xa8,0xd2,0xed,0xd4,0xf6,0xce,0xc8,0xd2,0xc7,0};
SI_SEGMENT_VARIABLE( RollGainCn[],const char ,SI_SEG_CODE) = {0xba,0xe1,0xb9,0xf6,0xb8,0xd0,0xb6,0xc8,0};
SI_SEGMENT_VARIABLE( PitchGainCn[],const char ,SI_SEG_CODE) = {0xb8,0xa9,0xd1,0xf6,0xb8,0xd0,0xb6,0xc8,0};
SI_SEGMENT_VARIABLE( YawGainCn[],const char ,SI_SEG_CODE) = {0xc6,0xab,0xba,0xbd,0xb8,0xd0,0xb6,0xc8,0};
SI_SEGMENT_VARIABLE( MountDirCn[],const char ,SI_SEG_CODE) = {0xb0,0xb2,0xd7,0xb0,0xb7,0xbd,0xcf,0xf2,0};
SI_SEGMENT_VARIABLE( WingTypeCn[],const char ,SI_SEG_CODE) = {0xd2,0xed,0xd0,0xcd,0xd1,0xa1,0xd4,0xf1,0};
SI_SEGMENT_VARIABLE( Position1Cn[],const char ,SI_SEG_CODE) = {0xce,0xbb,0xd6,0xc3,0x30,0x00,0};
SI_SEGMENT_VARIABLE( Position2Cn[],const char ,SI_SEG_CODE) = {0xce,0xbb,0xd6,0xc3,0x31,0x00,0};
SI_SEGMENT_VARIABLE( Position3Cn[],const char ,SI_SEG_CODE) = {0xce,0xbb,0xd6,0xc3,0x32,0x00,0};

SI_SEGMENT_VARIABLE( RollOffetCn[],const char ,SI_SEG_CODE) = {0xba,0xe1,0xb9,0xf6,0xb2,0xb9,0xb3,0xa5,0};
SI_SEGMENT_VARIABLE( PitchOffetCn[],const char ,SI_SEG_CODE) = {0xba,0xe1,0xb9,0xf6,0xb2,0xb9,0xb3,0xa5,0};
SI_SEGMENT_VARIABLE( AngleCn[],const char ,SI_SEG_CODE) = {0xbd,0xc7,0xb6,0xc8,0};
SI_SEGMENT_VARIABLE( AngularVelocityCn[],const char ,SI_SEG_CODE) = {0xbd,0xc7,0xcb,0xd9,0xb6,0xc8,0};
SI_SEGMENT_VARIABLE( GainDirCn[],const char ,SI_SEG_CODE) = {0xb7,0xbd,0xcf,0xf2,0};
SI_SEGMENT_VARIABLE( Switch[],const char ,SI_SEG_CODE) = {0xbf,0xaa,0xb9,0xd8,0};
SI_SEGMENT_VARIABLE( FlyMode[],const char ,SI_SEG_CODE) = {0xb7,0xc9,0xd0,0xd0,0xc4,0xa3,0xca,0xbd,0};


//language
SI_SEGMENT_VARIABLE( ChineseCn[],const char ,SI_SEG_CODE) = {0xd6,0xd0,0xce,0xc4,0} ;
SI_SEGMENT_VARIABLE( EnglishCn[],const char ,SI_SEG_CODE) = {0xd3,0xa2,0xce,0xc4,0} ;
SI_SEGMENT_VARIABLE( LanguageCn[],const char ,SI_SEG_CODE) = {0xd3,0xef,0xd1,0xd4,0} ;

SI_SEGMENT_VARIABLE( PageOptionLanguageEn[],CSTR ,SI_SEG_CODE) = {"Chinese","English"} ;
SI_SEGMENT_VARIABLE( PageOptionLanguageCn[],CSTR ,SI_SEG_CODE) = {ChineseCn,EnglishCn} ;
SI_SEGMENT_VARIABLE( PageOptionLanguageDef[2],CSTR ,SI_SEG_XDATA) ;

SI_SEGMENT_VARIABLE( MenuAirplaneStatility[],MENUITEM,SI_SEG_XDATA) = {
	{AirZWCn,0,0,0,9,0,0,0,"Flight Controller"},
	{FlyMode,PageMenuFlyMode,0,0,0,0,0,0,"Fly Mode"},
	{RollGainCn,PageMenuRollGain,0,0,0,0,0,0,"Roll Gain"},
	{PitchGainCn,PageMenuPitchGain,0,0,0,0,0,0,"Pitch Gain"},
	{YawGainCn,PageMenuYawGain,0,0,0,0,0,0,"Yaw Gain"},
	{RollOffetCn,0,0,-20,+20,  &AirParameter[7],0,0,"Roll offet"},
	{PitchOffetCn,0,0,-20,+20, &AirParameter[8],0,0,"Pitch offet"},
	{MountDirCn,0,PageOptionDirectionDef,0,3,&AirParameter[0], 0,0,"Mounting"},
	{WingTypeCn,0,PageOptionModelTypeDef,0,2,&AirParameter[12],0,0,"Wing"},
	{LanguageCn,PageMenuLanguage,0,0,0,0,0,0,"Language:"},

};

SI_SEGMENT_VARIABLE( roll_dir,int16_t,SI_SEG_IDATA) ;
SI_SEGMENT_VARIABLE( pitch_dir,int16_t,SI_SEG_IDATA) ;
SI_SEGMENT_VARIABLE( yaw_dir,int16_t,SI_SEG_IDATA) ;

SI_SEGMENT_VARIABLE( MenuRoll[] ,MENUITEM,SI_SEG_XDATA) = {
	{RollGainCn,0,0,0,3,0,0,0,"Roll Gain"},
	{GainDirCn,0,PageOptionGainDirDef,0,1,&roll_dir,0,0,"Direction"},
	{ AngleCn,0,0,0,100,&AirParameter[1],0,0,"Angle Gain"},
	{ AngularVelocityCn,0,0,0,100,&AirParameter[4],0,0,"Rate Gain"},
};

SI_SEGMENT_VARIABLE(  MenuPitch[] ,MENUITEM,SI_SEG_XDATA) = {
	{PitchGainCn,0,0,0,3,0,0,0,"Pitch Gain"},
	{GainDirCn,0,PageOptionGainDirDef,0,1,&pitch_dir,0,0,"Direction"},
	{AngleCn,0,0,0,+100,&AirParameter[2],0,0,"Angle Gain"},
	{AngularVelocityCn,0,0,0,+100,&AirParameter[5],0,0,"Rate Gain"},
};

SI_SEGMENT_VARIABLE(  MenuYaw[] ,MENUITEM,SI_SEG_XDATA) = {
	{YawGainCn,0,0,0,3,0,0,0,"Pitch Gain"},
	{GainDirCn,0,PageOptionGainDirDef,0,1,&yaw_dir,0,0,"Direction"},
	{AngleCn,0,0,0,+100,&AirParameter[3],0,0,"Angle Gain"},
	{AngularVelocityCn,0,0,0,+100,&AirParameter[6],0,0,"Rate Gain"},
};


SI_SEGMENT_VARIABLE(  MenuFlyMode[] ,MENUITEM,SI_SEG_XDATA) = {
		{FlyMode,0,0,0,4,0,0,0,"Fly Mode"},
		{Switch,0,PageOptionSwitchDef,0,3,&AirParameter[13],0,0,"Sw Select"},
		{Position1Cn,0,PageOptionFlyModeDef, 0, 3,&AirParameter[9] , 0,0,"SW-P1" },
		{Position2Cn,0,PageOptionFlyModeDef, 0, 3,&AirParameter[10] , 0,0,"SW-P2" },
		{Position3Cn,0,PageOptionFlyModeDef, 0, 3,&AirParameter[11] , 0,0,"SW-P3" },
};


SI_SEGMENT_VARIABLE( MenuLanguage[] ,MENUITEM,SI_SEG_XDATA) = {
	{LanguageCn,0,0,0,2,0,0,0,"Language"},
	{ChineseCn,0,0,0,0,0,0,0,"Chinese"},
	{ EnglishCn,0,0,0,0,0,0,0,"English"},
};


SI_SEGMENT_VARIABLE( sum_pre,static int16_t,SI_SEG_XDATA) ;
SI_SEGMENT_VARIABLE( sum,static int16_t,SI_SEG_XDATA) ;


//¼ì²â²ÎÊýÖµÊÇ·ñ¸Ä±ä
static void detect_value_change(int16_t *p_data,uint8_t size)
{

	uint8_t i  ;
	for( i = 0 ; i<size ; i++)
	{
		sum+= p_data[i] ;
	}
	sum=sum + roll_dir + pitch_dir + yaw_dir ;
	if(!UART_TX_flag){
		if(sum != sum_pre){
			sum_pre = sum ;
			UART_TX_flag |= WRITE_COMMAND ;
		}
	}
	sum = 0 ;
}


SI_SEGMENT_VARIABLE( flash_value ,uint8_t,SI_SEG_IDATA) ;
SI_SEGMENT_VARIABLE( UART_TX_flag ,uint8_t,SI_SEG_IDATA) ;

uint32_t PageMenuAirStable(uint8_t event)
{
	static MENUSTAT ms;
	uint8_t i ;

	if(event==PV_INIT)
	{
		LcdDrawStart(0, 0, LCD_W - 1, LCD_H - 1, DRAW_NWSE);
		UART_TX_flag |= READ_COMMAND ;
		flash_value = 0 ;
		LcdClear(0);
		if(!ms.Init)
		{
			ms.iFocus=ms.iStart=0;
			ms.Init=1;
		}
		ms.Total=MenuAirplaneStatility[0].Max;
		ms.DrawMask=PD_ALL;
		if(language == CHINESE){
			for(i = 0 ; i< 4 ; i++)
			{
				*(PageOptionDirectionDef + i) = *(PageOptionDirectionCn + i);
				*(PageOptionFlyModeDef + i) = *(PageOptionFlyModeCn + i);
			}

			for(i = 0;i < 3;i++)
			{
				*(PageOptionModelTypeDef + i) = *(PageOptionModelTypeCn + i);
			}

			for(i = 0 ; i < 2 ; i++){
				*(PageOptionLanguageDef + i) = *(PageOptionLanguageCn + i);
			}


		}else if(language == ENGLISH){
			 for(i = 0;i < 4;i++)
			 {
				*(PageOptionDirectionDef + i) = *(PageOptionDirectionEn + i);
				*(PageOptionFlyModeDef + i) = *(PageOptionFlyModeEn + i);

			 }

			 for(i = 0 ; i < 3 ; i++)
			 {
				 *(PageOptionModelTypeDef + i) = *(PageOptionModelTypeEn + i);
			 }

			 for(i = 0 ; i < 2 ; i++){
				 *(PageOptionLanguageDef + i) = *(PageOptionLanguageEn + i);
			 }
		}

		return 1;
	}

	if((!UART_TX_flag)&&flash_value){
		flash_value = 0 ;
		ms.DrawMask |= PD_VALUE|PD_LIST ;
	}


	detect_value_change(AirParameter, sizeof(AirParameter)/sizeof(AirParameter[0]));

	Page_Menu_Proc(MenuAirplaneStatility,&ms);

	if(KeyTstDown(KEY_ENT))
	{
		UART_TX_flag |= READ_COMMAND ;
		if(MenuAirplaneStatility[ms.iFocus+1].SubItem)
		{
			PageEnter((PAGEPROC)MenuAirplaneStatility[ms.iFocus+1].SubItem,PV_INIT);
		}else{
			Ent_flag = 1 ;
			ms.DrawMask |= PD_VALUE ;
		}
	}


	if(KeyTstDown(KEY_EXT))
	{
		Ent_flag = 0 ;
		UART_TX_flag = 0 ;
		PageReturn(PV_INIT);
	}

	return 0;
}

uint32_t PageMenuRollGain(uint8_t event)
{
	static MENUSTAT ms;
	int i ;
	if(event==PV_INIT)
	{
		LcdClear(0);;
		if(!ms.Init)
		{
			ms.iFocus=ms.iStart=0;
			ms.Init=1;
		}
		ms.Total=MenuRoll[0].Max;
		ms.DrawMask=PD_ALL;
		if(language == CHINESE){
			for(i = 0 ; i < 2 ;i++){
				*(PageOptionGainDirDef + i) = *(PageOptionGainDirCn + i);
			}
		}else if(language == ENGLISH){
			for(i = 0 ; i < 2 ;i++){
				*(PageOptionGainDirDef + i) = *(PageOptionGainDirEn + i);
			}
		}
		return 1;
	}

	detect_value_change(AirParameter, sizeof(AirParameter)/sizeof(AirParameter[0]));

	Page_Menu_Proc(MenuRoll,&ms);

	if(KeyTstDown(KEY_EXT))
	{
		if(!Ent_flag){
				PageReturn(PV_INIT);
		}
		Ent_flag = 0 ;
		ms.DrawMask |= PD_VALUE;
	}

	if(KeyTstDown(KEY_ENT)){
		Ent_flag = 1 ;
		ms.DrawMask |= PD_VALUE ;
	}


	return 0;

}

uint32_t PageMenuPitchGain(uint8_t event)
{
	static MENUSTAT ms;
	int i ;
	if(event==PV_INIT)
	{
		LcdClear(0);
		if(!ms.Init)
		{
			ms.iFocus=ms.iStart=0;
			ms.Init=1;
		}
		ms.Total=MenuPitch[0].Max;
		ms.DrawMask=PD_ALL;
		if(language == CHINESE){
			for(i = 0 ; i < 2 ;i++){
				*(PageOptionGainDirDef + i) = *(PageOptionGainDirCn + i);
			}
		}else if(language == ENGLISH){
			for(i = 0 ; i < 2 ;i++){
				*(PageOptionGainDirDef + i) = *(PageOptionGainDirEn + i);
			}
		}
		return 1;
	}


	detect_value_change(AirParameter, sizeof(AirParameter)/sizeof(AirParameter[0]));

	Page_Menu_Proc(MenuPitch,&ms);

	if(KeyTstDown(KEY_EXT))
	{
		if(!Ent_flag){
			PageReturn(PV_INIT);
		}
		Ent_flag = 0 ;
		ms.DrawMask |= PD_VALUE ;
	}

	if(KeyTstDown(KEY_ENT)){
		Ent_flag = 1 ;
		ms.DrawMask |= PD_VALUE ;
	}
	return 0;

}


uint32_t PageMenuYawGain(uint8_t event)
{
	static MENUSTAT ms;
	int i ;

	if(event==PV_INIT)
	{
		LcdClear(0);
		if(!ms.Init)
		{
			ms.iFocus=ms.iStart=0;
			ms.Init=1;
		}
		ms.Total=MenuYaw[0].Max;
		ms.DrawMask=PD_ALL;
		if(language == CHINESE){
			for( i = 0 ; i < 2 ;i++){
				*(PageOptionGainDirDef + i) = *(PageOptionGainDirCn + i);
			}
		}else if(language == ENGLISH){
			for( i = 0 ; i < 2 ;i++){
				*(PageOptionGainDirDef + i) = *(PageOptionGainDirEn + i);
			}
		}
		return 1;
	}

	detect_value_change(AirParameter, sizeof(AirParameter)/sizeof(AirParameter[0]));

	Page_Menu_Proc(MenuYaw,&ms);

	if(KeyTstDown(KEY_EXT)){
		if(!Ent_flag){
			PageReturn(PV_INIT);//Exit Page;
		}
		Ent_flag = 0 ;// Exit  Edit
		ms.DrawMask |= PD_VALUE ;
	}

	if(KeyTstDown(KEY_ENT)){
		Ent_flag = 1 ;  //Enter Edit
		ms.DrawMask |= PD_VALUE;
	}

	return 0;

}


uint32_t PageMenuFlyMode(uint8_t event)
{

	uint8_t i ;
	SI_SEGMENT_VARIABLE( ms ,static MENUSTAT,SI_SEG_IDATA) ;
	if(event==PV_INIT)
	{
		Clear_Screen();
		if(!ms.Init)
		{
			ms.iFocus=ms.iStart=0;
			ms.Init=1;
		}
		ms.Total=MenuFlyMode[0].Max;
		ms.DrawMask=PD_ALL;

		if(language == CHINESE){
			for( i = 0 ; i < 4 ;i++)
			{
				*(PageOptionSwitchDef + i) = *(PageOptionSwitchCn + i);
			}
		}else if(language == ENGLISH){
			for( i = 0 ; i < 4 ;i++)
			{
				*(PageOptionSwitchDef + i) = *(PageOptionSwitchEn + i);
			}
		}
		return 1;
	}

	detect_value_change(AirParameter, sizeof(AirParameter)/sizeof(AirParameter[0]));

	Page_Menu_Proc(MenuFlyMode,&ms);

	if(KeyTstDown(KEY_EXT))
	{
		if(!Ent_flag){
			PageReturn(PV_INIT);
		}
		Ent_flag = 0 ;
		ms.DrawMask |= PD_VALUE;
	}

	if(KeyTstDown(KEY_ENT)){
		Ent_flag = 1 ;
		ms.DrawMask |= PD_VALUE ;
	}


	return 0;

}


uint32_t PageMenuLanguage(uint8_t event)
{
	SI_SEGMENT_VARIABLE( ms ,static MENUSTAT,SI_SEG_IDATA) ;

	if(event == PV_INIT)
	{
		LcdClear(0);
		LcdDrawStart(0, 0,LCD_W-1, LCD_H-1, DRAW_NWSE);
		if(!ms.Init)
		{
			ms.iFocus=ms.iStart=0;
			ms.Init=1;
		}
		ms.Total=MenuLanguage[0].Max;
		ms.DrawMask=PD_ALL;

	}

	Page_Menu_Proc(MenuLanguage,&ms);

	if(KeyTstDown(KEY_ENT))
	{
		language = ms.iFocus  ;
		PageReturn(PV_INIT);
	}

	if(KeyTstDown(KEY_EXT))
	{
		PageReturn(PV_INIT) ;
	}
	return 0 ;
}



