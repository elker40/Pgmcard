/*
 * Lcd.c
 *
 *  Created on: 2016-8-12
 *      Author: Administrator
 */
#include "Lcd.h"


volatile uint8_t  LcdBw;
void delay(uint16_t count)
{
	while(count-- > 0);
}

void SPI_Write_Byte (uint8_t writeData)
{
	while(!SPI0CN0_NSSMD0);

	SPI0CN0_NSSMD0 = 0 ;

	SPI0DAT = writeData;

	while (SPI0CFG & 0x80) ;
	SPI0CN0_NSSMD0 = 1;

	while(!SPI0CN0_NSSMD0);
}


void  Lcd_Data (uint8_t writeData)
{
	RS = 1 ;         //write data signal
	SPI_Write_Byte(writeData);
}


void Lcd_Cmd (uint8_t writeCmd)
{
	RS = 0 ;       //write command signal
	SPI_Write_Byte (writeCmd);
}


void Lcd_Init(void)
{
	LcdBw = 0 ;
	RESET = 0 ;
	delay(100);
	RESET = 1 ;

	delay(100);
	Lcd_Cmd(0xe2);
	delay(5);
	Lcd_Cmd(0x2C);
	delay(5);
	Lcd_Cmd(0x2E);
	delay(5);
	Lcd_Cmd(0x2F);
	delay(5);

	Lcd_Cmd(0x24);
	Lcd_Cmd(0x81);
	Lcd_Cmd(0x1A);
	Lcd_Cmd(0xa2);
	Lcd_Cmd(0xc8);
	Lcd_Cmd(0xa0);
	Lcd_Cmd(0x40);
	Lcd_Cmd(0xaf);

}


void Lcd_address(uint8_t page , uint8_t column)
{
	Lcd_Cmd(0xb0 | (page & 0x07));
	Lcd_Cmd(((column >> 4)&0x0f) + 0x10);
	Lcd_Cmd(column & 0x0f);
}





void Lcd_Set_Page(uint8_t page)
{
	Lcd_Cmd(0xb0 + page);
}


void Lcd_Set_Column(uint8_t column)
{
	Lcd_Cmd(((column >> 4)&0x0f) + 0x10);
	Lcd_Cmd(column & 0x0f);//LSB
}



















