//-----------------------------------------------------------------------------
// Includes
//-----------------------------------------------------------------------------
#include <SI_EFM8UB2_Register_Enums.h>                  // SFR declarations
#include "InitDevice.h"
#include "Lcd.h"
#include "page.h"
#include "PageMenu.h"
// $[Generated Includes]
// [Generated Includes]$

#define  DEBUG  1
#define  DEBUG_TX  0
SI_SEGMENT_VARIABLE( UART_TX_Buffer[UART_BUFFER_SIZE] ,uint8_t,SI_SEG_IDATA) ;
SI_SEGMENT_VARIABLE( UART_RX_Buffer[UART_BUFFER_SIZE] ,uint8_t,SI_SEG_IDATA) = {0};
SI_SEGMENT_VARIABLE( UART_Data_Handler_Flag ,uint8_t,SI_SEG_XDATA);

SI_SEGMENT_VARIABLE( PageAlertText ,char *,SI_SEG_IDATA) ;
SI_SEGMENT_VARIABLE( PageAlertDelay ,uint32_t,SI_SEG_IDATA) ;
SI_SEGMENT_VARIABLE( PageAlertMsg ,uint8_t,SI_SEG_IDATA) ;

SI_SEGMENT_VARIABLE( timer_uart ,uint16_t,SI_SEG_IDATA);
void Delay_us(uint16_t count);
void UART1_Write_Encode(void);
void UART1_Read_Encode(void);
void UART1_Write_Buffer(uint8_t *buffer, uint8_t size);
void UART1_RX_Decode(void);
void PageAlertDraw(void) ;
void PageAlertModel(CSTR text,uint32_t delay) ;
void UART_RX_Handler(void) ;
uint8_t Crc_Data = 0;

//-----------------------------------------------------------------------------
// main() Routine
// ----------------------------------------------------------------------------
int main(void) {
	// Call hardware initialization routine
	enter_DefaultMode_from_RESET();
	UART_TX_Buffer[0] = 0x8D; //0x8D
	Lcd_Init();
	LcdClear(0);
	PageAlertModel("Reading...",100) ;
	PageSet(PageMenuAirStable, PV_INIT);
	while (1) {
		PageStack[PageStackIdx](PV_RUN);
		if (timer_cnt - timer_uart > 3) {
			timer_uart = timer_cnt;
			if (UART_TX_flag & READ_COMMAND) {//read command sent_flag
				UART1_Read_Encode();
				UART1_Write_Buffer(UART_TX_Buffer, 4);
			} else if (UART_TX_flag & WRITE_COMMAND) {//witer command sent_flag ;
				UART1_Write_Encode();
				UART1_Write_Buffer(UART_TX_Buffer, 13);
			}
		}

		if (UART_Data_Handler_Flag) {
			UART_Data_Handler_Flag = 0;
			UART_RX_Handler();

		}


// $[Generated Run-time code]
// [Generated Run-time code]$
	}

}

void Delay_us(uint16_t count) {
	uint16_t i, j;
	for (i = 0; i < count; i++) {
		for (j = 0; j < 10000; j++)
			;
	}
}

void UART1_Read_Encode(void) {
	UART_TX_Buffer[1] = 0x01; //0x01
	UART_TX_Buffer[2] = 0xFF; //0xff
	UART_TX_Buffer[3] = UART_TX_Buffer[0] + UART_TX_Buffer[1]
			+ UART_TX_Buffer[2];
}

void UART1_Write_Encode(void) {
	UART_TX_Buffer[1] = 0x0A;
	UART_TX_Buffer[2] = AirParameter[1] + roll_dir * 100;
	UART_TX_Buffer[3] = AirParameter[2] + pitch_dir * 100;
	UART_TX_Buffer[4] = AirParameter[3] + yaw_dir * 100;
	UART_TX_Buffer[5] = AirParameter[4] + roll_dir * 100;
	UART_TX_Buffer[6] = AirParameter[5] + pitch_dir * 100;
	UART_TX_Buffer[7] = AirParameter[6] + yaw_dir * 100;
	UART_TX_Buffer[8] = AirParameter[7] + 20;
	UART_TX_Buffer[9] = AirParameter[8] + 20;
	UART_TX_Buffer[10] = AirParameter[9] | (AirParameter[10] << 2)
			| (AirParameter[11] << 4)|(AirParameter[13] << 6);
	UART_TX_Buffer[11] = (AirParameter[0] << 2) | AirParameter[12];
	UART_TX_Buffer[12] = UART_TX_Buffer[0] + UART_TX_Buffer[1]
			+ UART_TX_Buffer[2] + UART_TX_Buffer[3] + UART_TX_Buffer[4]
			+ UART_TX_Buffer[5] + UART_TX_Buffer[6] + UART_TX_Buffer[7]
			+ UART_TX_Buffer[8] + UART_TX_Buffer[9] + UART_TX_Buffer[10]
			+ UART_TX_Buffer[11] ;

}

void UART1_Write_Buffer(uint8_t *buffer, uint8_t size) {
	int i = 0;
	for (i = 0; i < size; i++) {
		SBUF1 = buffer[i];
		while(!(SCON1 & 0x02)) ;
		SCON1 &= ~0x02 ;
	}

}

void UART1_RX_Decode(void) {
	if (UART_RX_Buffer[2] > 100) {
		roll_dir = 1;
	} else if (UART_RX_Buffer[2] <= 100) {
		roll_dir = 0;
	}

	if (UART_RX_Buffer[3] > 100) {
		pitch_dir = 1;
	} else if (UART_RX_Buffer[3] <= 100) {
		pitch_dir = 0;
	}

	if (UART_RX_Buffer[4] > 100) {
		yaw_dir = 1;
	} else if (UART_RX_Buffer[4] <= 100) {
		yaw_dir = 0;
	}

	AirParameter[1] = UART_RX_Buffer[2] - roll_dir * 100; //Angel AIL
	AirParameter[2] = UART_RX_Buffer[3] - pitch_dir * 100; //Angel ELE
	AirParameter[3] = UART_RX_Buffer[4] - yaw_dir * 100; //Angel RUD
	AirParameter[4] = UART_RX_Buffer[5] - roll_dir * 100; //Angular Velocity AIL
	AirParameter[5] = UART_RX_Buffer[6] - pitch_dir * 100; //Angular Velocity ELE
	AirParameter[6] = UART_RX_Buffer[7] - yaw_dir * 100; //Angular Velocity RUD
	AirParameter[7] = UART_RX_Buffer[8] - 20;
	AirParameter[8] = UART_RX_Buffer[9] - 20;
	AirParameter[9] = UART_RX_Buffer[10] & 0x03;
	AirParameter[10] = (UART_RX_Buffer[10] >> 2) & 0x03;
	AirParameter[11] = (UART_RX_Buffer[10] >> 4) & 0x03;
	AirParameter[13] = (UART_RX_Buffer[10] >> 6) & 0x03 ;
	AirParameter[12] = UART_RX_Buffer[11] & 0x03;
	AirParameter[0] = (UART_RX_Buffer[11] >> 2) & 0x03;

}
void UART_RX_Handler(void)
{
	int i ;
	for(i = 0 ; i < UART_RX_Buffer[1] + 2 ; i++)
	{
		Crc_Data += UART_RX_Buffer[i] ;
	}

	if(Crc_Data == UART_RX_Buffer[i]){
		Crc_Data = 0 ;
		if(UART_RX_Buffer[0] == 0xD8 && UART_RX_Buffer[2] == 0xCC && UART_RX_Buffer[1] == 0x01){
			UART_TX_flag = 0 ;
		}else if(UART_RX_Buffer[0] == 0xD8 && UART_RX_Buffer[1] == 0x0A){
			UART_TX_flag = 0 ;
			UART1_RX_Decode();

		}
	}
}
void PageAlertDraw(void)
{
	int s,p,l;
	l=6*strlen(PageAlertText);
	s=(LCD_W-l)/2;
	p=(LCD_W+l)/2;
	LcdDrawStart(0, 0,LCD_W-1, LCD_H-1, DRAW_NWSE);

	if(PageAlertDelay)
	{
		LcdDrawRect(s-6, 9,p+6,56,0);
		LcdDrawRect(s-5,10,p+5,55,1);
		LcdDrawRect(s-4,11,p+3,53,0);
		LcdDrawText(s,18,PageAlertText);		//??????3?
		LcdBw=1;
		LcdDrawText(LCD_W/2-16,36," EXT ");		//????°′?￥
		LcdBw=0;
	}

	LcdDrawStop();
}

void PageAlertModel(CSTR text,uint32_t delay)
{
	if(!text)	return;
	PageAlertText=(char*)text;
	PageAlertDelay=delay;
	PageAlertDraw();


	UART_TX_flag = READ_COMMAND ;
	while(!KeyTstDown(KEY_EXT) && (delay--))
	{
		if(UART_TX_flag){
			UART1_Read_Encode();
			UART1_Write_Buffer(UART_TX_Buffer, 4);
		}else{
			text = "Read success!" ;
			PageAlertText=(char*)text;
			PageAlertDraw();
		}

		if (UART_Data_Handler_Flag) {
			UART_Data_Handler_Flag = 0;
			UART_RX_Handler();
		}

		Delay_us(10) ;
	}

}



