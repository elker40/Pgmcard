/*
 * Page.c
 *
 *  Created on: 2016-8-13
 *      Author: Administrator
 */
#include "page.h"
#include "string.h"
PAGEPROC PageStack[PAGELEVEL];
uint8_t  PageStackIdx;

SI_SEGMENT_VARIABLE( language,int16_t,SI_SEG_IDATA) = 0 ;
void PageEnter(PAGEPROC page,uint8_t msg)
{
	if(PageStackIdx>=PAGELEVEL-1)	return;
	PageStack[++PageStackIdx]=page;
	page(msg);
}

void PageReturn(uint8_t msg)
{
	if(PageStackIdx>0)	PageStackIdx--;
	PageStack[PageStackIdx](msg);
}

void PageSet(PAGEPROC page,uint8_t msg)
{
	PageStack[PageStackIdx=0]=page;
	page(msg);
}


uint8_t Ent_flag = 0 ;
void Page_Menu_Proc(CMENUITEM *pmi,MENUSTAT *pms)
{

		MENUITEM *mi=(MENUITEM *)&pmi[pms->iFocus+1];
		if(pms->DrawMask)
		{
			LcdDrawStart(0, 0,LCD_W-1, LCD_H-1, DRAW_NWSE);


			if(pms->DrawMask&PD_TITLE)
			{
				LcdDrawRect(0, 0,127,13,0);
				if(language == ENGLISH){
					LcdDrawTextEn(3,0,pmi[0].ETitle);  //language
				}else if(language == CHINESE){
					LcdDrawTextCn(3,0,pmi[0].Title,strlen(pmi[0].Title));
				}
				LcdDrawHLine(0,127,14,1);
			}

			if(pms->DrawMask&PD_IDX)
			{
				if(pms->Total>9)
				{
					LcdDrawMiniInt(110,4,pms->iFocus+1,2,0,0xff,1);
					LcdDrawMiniNum(110,4,LCD_MN_SPA);
					LcdDrawMiniInt(114,4,pms->Total,2,0,0xff,0);
				}
				else
				{
					LcdDrawMiniInt(120,4,pms->iFocus+1,2,0,0xff,1);
					LcdDrawMiniNum(120,4,LCD_MN_SPA);
					LcdDrawMiniInt(124,4,pms->Total,1,0,0xff,0);
				}
			}


			if(pms->DrawMask&(PD_LIST|PD_VALUE))
			{
				int i,s,p,y,idx;
				for(i=0,y=16;i<LCD_MENULINES_CN && i<pms->Total;i++,y+=16)
				{
					idx=pms->iStart+i;
					LcdBw=(idx==pms->iFocus);
					idx++;

					if((pms->DrawMask &PD_LIST) || LcdBw)
					{
						LcdDrawRect(1,y,126,y+15,LcdBw);
						LcdDrawMiniInt(2,y+4,idx,2,0,0xff,0);
						LcdDrawMiniNum(10,y+4,LCD_MN_DOT);
					 // LcdDrawText(13,y,pmi[idx].Title);//language
						if(language == ENGLISH){
							LcdDrawTextEn(13,y,pmi[idx].ETitle);
						}else if(language == CHINESE){
							LcdDrawTextCn(13,y,pmi[idx].Title,strlen(pmi[idx].Title));
						}

						if(pmi[idx].SubItem)
						{
							if(LcdBw)	LcdDrawText(114,y,"\6\2");//>>
							else		LcdDrawText(120,y,"\2");//>
						}


						if(pmi[idx].Text)
						{
							s=110-6*strlen(pmi[idx].Text);
							if(language == ENGLISH){
								p=LcdDrawTextEn(s,y,pmi[idx].Text);
							}else if(language == CHINESE){
								p=LcdDrawTextCn(s,y,pmi[idx].Text,strlen(pmi[idx].Text));
							}
//							p=LcdDrawText(s,y,pmi[idx].Text);//language
							LcdDrawHLine(s-1,p+1,y+14,0);
						}else if(pmi[idx].pValue){
							int16_t v=*pmi[idx].pValue;
							if(v>pmi[idx].Max) v=pmi[idx].Max;
							if(v<pmi[idx].Min) v=pmi[idx].Min;
							*pmi[idx].pValue=v;


							if(pmi[idx].Values){

								s=118-6*strlen(pmi[idx].Values[v]);
								if(language == ENGLISH){
									p=LcdDrawTextEn(s,y,(char*)pmi[idx].Values[v]);
								}else if(language == CHINESE){
									p=LcdDrawTextCn(s,y,(char*)pmi[idx].Values[v],strlen((char*)pmi[idx].Values[v]));
								}
//								p=LcdDrawTextEn(s,y,(char*)pmi[idx].Values[v]);//Menu Text//language
							}else{

								LcdDrawInt(s=90,y,v,3,*((uint8_t*)pmi[idx].Data),0,0);//Menu  Data
								p=90+24+2;
							}


							if(Ent_flag){
								if(LcdBw)
								{
									if(v==pmi[idx].Max)
										LcdDrawText(120,y,"\4");//SPIN
									else if(v==pmi[idx].Min)
										LcdDrawText(120,y,"\5");//SPIN
									else
										LcdDrawText(120,y,"\3");//SPIN
									LcdDrawHLine(s-1,p+1,y+14,0);
								}
							}

						}

					}
					LcdBw=0;
				}
			}

			LcdDrawStop();
			pms->DrawMask=0;
		}



		if(Ent_flag){


			if(KeyTstDown(KEY_R))
			{
				if(mi->pValue)
				{
					if(*mi->pValue<mi->Max)
					{
						(*mi->pValue)++;
						pms->DrawMask|=PD_VALUE;
					}
				}
			}

			if(KeyTstDown(KEY_L))
			{
				if(mi->pValue)
				{
					if(*mi->pValue>mi->Min)
					{
						(*mi->pValue)--;
						pms->DrawMask|=PD_VALUE;
					}
				}
			}

		}else{

			if(KeyTstDown(KEY_R))
			{
				if(pms->iFocus>0) pms->iFocus--;
				else		 pms->iFocus=pms->Total-1;
				pms->DrawMask=PD_LIST|PD_IDX;
			}

			if(KeyTstDown(KEY_L))
			{
				if(pms->iFocus<pms->Total-1) pms->iFocus++;
				else		 		pms->iFocus=0;
				pms->DrawMask=PD_LIST|PD_IDX;
			}
		}

		if(pms->iFocus>=pms->Total)	pms->iFocus=pms->Total-1;
		if(pms->iFocus<pms->iStart) 				pms->iStart=pms->iFocus;
		if(pms->iFocus>pms->iStart+LCD_MENULINES_CN-1) pms->iStart=pms->iFocus-LCD_MENULINES_CN+1;
}
