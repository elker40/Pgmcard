/*
 * LcdDraw.h
 *
 *  Created on: 2016-8-12
 *      Author: Administrator
 */

#ifndef LCDDRAW_H_
#define LCDDRAW_H_

#include "Lcd.h"
#include <string.h>
#include <si_toolchain.h>

#define  HZNUM    56

enum DrawDir
{
	DRAW_NWSE ,
	DRAW_SWNE ,
};

#define LCD_MN_SPA		17
#define LCD_MN_DOT		10
#define LCD_MN_MINUS	11
#define LCD_MN_MW1		12
#define LCD_MN_MW2		13
#define LCD_MN_MW3		14
#define LCD_MN_SP		15
#define LCD_MN_PLUS		16
#define LCD_MN_SPA		17
#define LCD_MN_COL		18
#define LCD_MN_A		23
#define LCD_MN_CHAR(X)	(X-'A'+LCD_MN_A)

extern void Clear_Screen(void) ;
extern void LcdClear(uint8_t bw) ;
extern void LcdDrawStart(uint16_t  x0, uint16_t y0, uint16_t x1, uint16_t y1, enum DrawDir _dir) ;
extern SI_SEGMENT_VARIABLE(Gu[6], const uint8_t, SI_SEG_CODE) ;
extern void LcdDrawStop(void) ;

extern void LcdDrawPixel(uint16_t color) ;

extern void LcdDrawPixelXY(uint16_t x, uint16_t y, uint16_t color) ;

extern void LcdDrawRect(uint16_t x1,uint16_t y1,uint16_t x2,uint16_t y2,uint16_t color) ;

extern void LcdWriteHzLine(uint16_t  x,uint16_t y,uint16_t mask ,uint16_t numble) ;

extern void LcdWriteHzChar(uint16_t x,uint16_t y,uint16_t hz) ;

extern void LcdWriteEngChar(uint16_t x,uint16_t y,uint8_t c);

extern uint16_t LcdDrawText(uint16_t x,uint16_t y,char *hz);

uint16_t LcdDrawTextEn(uint16_t x , uint16_t y , char *en) ;

uint16_t LcdDrawTextCn(uint16_t x,uint16_t y,uint8_t *Cn,uint8_t size) ;

extern void LcdDrawMaskY(uint16_t x,uint16_t y,uint8_t mask,uint8_t n);

extern void LcdDrawMiniNum(uint16_t x,uint16_t y,uint8_t num);

extern void  LcdDrawMiniInt(uint16_t x,uint16_t y,int16_t value,uint8_t n,uint8_t dot,uint8_t plus,uint8_t ar);

extern void LcdDrawHLine(uint16_t x1,uint16_t x2,uint16_t y,uint16_t color);

extern void  LcdDrawInt(uint16_t x,uint16_t y,int16_t value,uint8_t n,uint8_t dot,uint8_t plus,uint8_t ar);
#endif /* LCDDRAW_H_ */
