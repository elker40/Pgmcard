/*
 * PageMenu.h
 *
 *  Created on: 2016-8-17
 *      Author: Administrator
 */

#ifndef PAGEMENU_H_
#define PAGEMENU_H_

#include "page.h"

extern uint8_t send_parameter_flag ;
#define  READ_COMMAND    0x01
#define  WRITE_COMMAND   0x02
extern SI_SEGMENT_VARIABLE( UART_TX_flag ,uint8_t,SI_SEG_IDATA) ;
extern SI_SEGMENT_VARIABLE( UART_Data_Handler_Flag ,uint8_t,SI_SEG_XDATA);

extern SI_SEGMENT_VARIABLE( AirParameter[14],int16_t,SI_SEG_IDATA) ;
extern SI_SEGMENT_VARIABLE( roll_dir,int16_t,SI_SEG_IDATA) ;
extern SI_SEGMENT_VARIABLE( pitch_dir,int16_t,SI_SEG_IDATA) ;
extern SI_SEGMENT_VARIABLE( yaw_dir,int16_t,SI_SEG_IDATA) ;

//subitem process
uint32_t PageMenuAirStable(uint8_t event) ;
uint32_t PageMenuRollGain(uint8_t event) ;
uint32_t PageMenuPitchGain(uint8_t event) ;
uint32_t PageMenuYawGain(uint8_t event) ;
uint32_t PageMenuFlyMode(uint8_t event) ;
uint32_t PageMenuLanguage(uint8_t event) ;

extern SI_SEGMENT_VARIABLE( FaceUp[5],const char,SI_SEG_CODE) ;
extern SI_SEGMENT_VARIABLE( FaceDw[5],const char,SI_SEG_CODE) ;
extern SI_SEGMENT_VARIABLE( FaceLf[7],const char,SI_SEG_CODE) ;
extern SI_SEGMENT_VARIABLE( FaceLRi[7],const char,SI_SEG_CODE) ;
extern SI_SEGMENT_VARIABLE( PageOptionDirectionCn[4],CSTR,SI_SEG_CODE) ;


extern SI_SEGMENT_VARIABLE( NormalWings[7],const char,SI_SEG_CODE) ;
extern SI_SEGMENT_VARIABLE(TriangleWings[7],const char ,SI_SEG_CODE);
extern SI_SEGMENT_VARIABLE(VWings[9],const char ,SI_SEG_CODE) ;




#endif /* PAGEMENU_H_ */
