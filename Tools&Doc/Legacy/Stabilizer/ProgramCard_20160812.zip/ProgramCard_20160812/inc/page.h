/*
 * page.h
 *
 *  Created on: 2016-8-13
 *      Author: Administrator
 */

#ifndef PAGE_H_
#define PAGE_H_

#include "LcdDraw.h"

#define  PAGELEVEL   2

#define PD_TITLE	1
#define PD_LIST		2
#define PD_IDX		4
#define PD_VALUE	8
#define PD_ALL		0xff

#define LCD_MENULINES_CN  3

#define  KEY_0_STATE  0
#define  KEY_1_STATE  1

#define  CHINESE     0x00
#define  ENGLISH     0x01
#define  KEY_MASK     0xff
#define  KEY_L      0x01
#define  KEY_R      0x02
#define  KEY_ENT    0x04
#define  KEY_EXT    0x08


typedef uint32_t (*PAGEPROC)(uint8_t event);
typedef const char *  CSTR ;

typedef struct{
	char  *Title ;
	void  *SubItem;
	CSTR  *Values ;
	int16_t Min,Max ;
	int16_t *pValue ;
	void  *Data ;
	char  *Text ;
	char  *ETitle ;

}MENUITEM,*PMENUITEM ;


typedef struct{
	uint8_t Init;
	uint8_t DrawMask,iFocus,iStart,Total;
	uint8_t Param;
}MENUSTAT;


typedef const MENUITEM  CMENUITEM ;

#define PV_RUN		0
#define PV_INIT		1
#define PV_END		2
#define PV_REDRAW	3
#define PV_TIMER	4
#define PV_USER		0x80
extern SI_SEGMENT_VARIABLE( language,int16_t,SI_SEG_IDATA) ;
extern PAGEPROC PageStack[PAGELEVEL];
extern uint8_t  PageStackIdx;
extern uint8_t  Ent_flag ;
extern uint8_t KeyTstDown(uint8_t mask) ;
extern void Page_Menu_Proc(CMENUITEM *pmi,MENUSTAT *pms);
extern void PageReturn(uint8_t msg) ;
extern void PageEnter(PAGEPROC page,uint8_t msg);
void PageSet(PAGEPROC page,uint8_t msg) ;

#endif /* PAGE_H_ */
