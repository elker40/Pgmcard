/*
 * Lcd.h
 *
 *  Created on: 2016-8-12
 *      Author: Administrator
 */

#ifndef LCD_H_
#define LCD_H_

#include <SI_EFM8UB2_Register_Enums.h>                  // SFR declarations

#define  LCD_PAGES        8
#define  LCD_PHY_WIDTH   129

#define  LCD_W    128
#define  LCD_H    64
SI_SBIT (RS, SFR_P1, 1);
SI_SBIT (RESET,SFR_P1, 2);

extern volatile uint8_t LcdBw;

extern void delay(uint16_t count);

extern void SPI_Write_Byte(uint8_t writeData);

extern void Lcd_Data (uint8_t writeData);

extern void Lcd_Cmd (uint8_t writeCmd);

extern void Lcd_Init(void);

extern void Lcd_address(uint8_t page,uint8_t column);

extern void Lcd_Set_Page(uint8_t page);

extern void Lcd_Set_Column(uint8_t column) ;



#endif /* LCD_H_ */
